#!/usr/bin/env python3
"""Patch Hybrid/index.html locally; keeps a backup and refuses unknown source shapes."""
from pathlib import Path
import sys, shutil
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('index.html')
if not p.is_file(): raise SystemExit('ERROR: Pass the path to your Hybrid index.html')
s=p.read_text(encoding='utf-8')
if 'HYBRID_TRAINING_FIX_2026_11_08' in s: raise SystemExit('Already patched; no changes made')
original=s

def replace(old,new,expected=1):
 global s
 count=s.count(old)
 if count!=expected: raise SystemExit(f'ERROR: expected {expected} match(es), found {count}: {old[:90]!r}; no file changed')
 s=s.replace(old,new)

# Half marathon phases: five runs Mon/Wed/Thu/Sat/Sun, Tuesday lower, Friday rest.
replace("if(block===1){indexes=runDays===5?[0,2,3,5,6]:[0,2,5,6];weights=runDays===5?[.15,.21,.15,.18,.31]:[.18,.23,.19,.40];}",
        "if(block===1){indexes=runDays===5?[0,2,3,5,6]:[0,2,5,6];weights=runDays===5?[.15,.20,.15,.19,.31]:[.18,.22,.20,.40];}")
replace("if(block===2){indexes=runDays===5?[0,2,3,5,6]:[0,2,5,6];weights=runDays===5?[.14,.20,.14,.16,.36]:[.17,.22,.18,.43];}",
        "if(block===2){indexes=runDays===5?[0,2,3,5,6]:[0,2,5,6];weights=runDays===5?[.14,.19,.14,.17,.36]:[.17,.22,.18,.43];}")
# Base, development and peak share the same predictable weekly pattern.
replace("if(block===0){\n   ds[0].lift='upperA';", "if([0,1,2].includes(block)){\n   ds[0].lift='upperA';")
# Explicitly keep Friday as rest in half-marathon phases; Thursday upper B.
replace("   ds[5].title='Saturday threshold';\n   ds[6].title='Sunday long run';",
        "   ds[4].lift=undefined;ds[4].type='rest';ds[4].title='Friday rest / mobility';\n   ds[5].lift=undefined;ds[5].title='Saturday threshold';\n   ds[6].lift=undefined;ds[6].title='Sunday long run';")
# Wednesday speed rotation throughout base/development/peak, not only winter.
replace("else if(block===0&&i===2){", "else if([0,1,2].includes(block)&&i===2){")
# Saturday threshold should be conditional on recovery across development and peak too.
replace("else if([1,2].includes(block)&&i===5){x=quality(km,block===2?'thresholdLong':'threshold');d.title='Saturday threshold';}",
        "else if([1,2].includes(block)&&i===5){\n   const mode=coachDecision(w,block).mode;\n   if(mode==='normal'&&km>=7){x=quality(km,block===2?'thresholdLong':'threshold');d.title='Saturday threshold';}\n   else{x=easy(km,'recovery');d.title='Saturday easy · recovery priority';}\n  }")
# Friday rest, Saturday quality, Sunday long during base and half development.
# Fix unreachable loop-rehearsal branch by placing it before generic Sunday long.
replace("  else if(i===6)x=easy(km,'long');\n  else if((i===6&&[1,2].includes(block))||(i===5&&block===8)){",
        "  else if((i===6&&[1,2].includes(block))||(i===5&&block===8)){")
replace("   }else x=easy(km,'long');\n  }\n  if(block===0&&i===4", "   }else x=easy(km,'long');\n  }\n  else if(i===6)x=easy(km,'long');\n  if(block===0&&i===4")
# Remove unreachable Friday strides (Friday is rest); don't prescribe extra running on rest days.
replace("  if(block===0&&i===4&&!deload)x.detail+=' Finish with 4 × 20 sec relaxed strides, walking 60–90 sec between. Include strides in the planned distance.';\n", "")
# Guard against inaccurate claims that the app can infer recovery from a calendar.
marker='<!-- HYBRID_TRAINING_FIX_2026_11_08: five-run half-marathon schedule, Friday rest, rotating Wednesday track, Saturday threshold, Sunday long, recovery-aware quality -->\n'
if '<!DOCTYPE html>' in s: s=s.replace('<!DOCTYPE html>', '<!DOCTYPE html>\n'+marker,1)
else: s=marker+s
backup=p.with_suffix('.before-training-update.html')
if backup.exists(): raise SystemExit(f'ERROR: backup already exists: {backup}; no changes made')
shutil.copy2(p,backup)
p.write_text(s,encoding='utf-8')
print(f'Updated {p}; original saved to {backup}')
