HYBRID TRAINING CODE UPDATE — NOVEMBER 8, 2026

This is a SOURCE PATCH, not a ready-to-upload website.

1. Export a backup of your training data from the live app first.
2. Download your GitHub Hybrid repository as a ZIP and extract it.
3. Put apply_training_update.py beside index.html.
4. Run: python3 apply_training_update.py index.html
5. Review the changed site locally, especially each 2027 phase, before uploading index.html to GitHub.
6. The script creates index.before-training-update.html as a source backup.

This patch targets the code inspected on Nov 8, 2026. It refuses to run if expected
code fragments differ, rather than risk corrupting a changed version.

Changes: Friday rest in half-marathon development/peak; Wednesday track rotation
across base/development/peak; recovery-aware Saturday threshold; Sunday long run;
fix unreachable hourly-loop rehearsal branch; remove dead Friday running instruction.

NOT YET VERIFIED: Full browser integration, all future phase dates, data import,
training safety, or GitHub deployment. This is not a 100/100 certification.
